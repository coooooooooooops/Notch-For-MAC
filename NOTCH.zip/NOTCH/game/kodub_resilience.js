/**
 * kodub_resilience.js  (v4 — one banner, ever, then fully removed)
 *
 * Per endpoint (user / leaderboard / leaderboardUserEntry / iceServers):
 *   - First time it fails: retry a few times with backoff, SILENTLY (no
 *     banner flashing on every attempt).
 *   - If it's still failing after those retries: show ONE banner with a
 *     final message, then after a few seconds remove that banner element
 *     from the page entirely (not just faded/hidden).
 *   - After that: fully silent forever this session. No more retries, no
 *     more banners, no DOM element left behind at all.
 *   - On success: no banner at all, ever.
 *
 * ROOT CAUSE REMINDER: your DevTools screenshot showed a CORS block
 * ("No 'Access-Control-Allow-Origin' header"), which XHR reports as
 * status 0 before any real response arrives. That's a hard block the
 * browser enforces — no client-side retry/backoff code can make it
 * succeed. This file only controls how failure is *displayed*, once,
 * briefly, and then never again.
 */
(() => {
  "use strict";

  const DEBUG = true;
  const log = (...args) => DEBUG && console.log("[kodub_resilience]", ...args);

  const TARGET_PATTERNS = [
    { name: "user", re: /^https:\/\/vps\.kodub\.com\/v6\/user(\?|$)/ },
    { name: "leaderboard", re: /^https:\/\/vps\.kodub\.com\/v6\/leaderboard(\?|$)/ },
    { name: "leaderboardUserEntry", re: /^https:\/\/vps\.kodub\.com\/v6\/leaderboardUserEntry(\?|$)/ },
    { name: "iceServers", re: /^https:\/\/vps\.kodub\.com\/v6\/iceServers(\?|$)/ },
  ];

  const MAX_RETRIES = 3; // total attempts = 4, then go silent for this endpoint
  const BASE_DELAY_MS = 500;
  const MAX_DELAY_MS = 4000;
  const RETRYABLE_STATUSES = new Set([503]);
  const BANNER_VISIBLE_MS = 3500; // how long the ONE banner stays before being removed

  const silenced = new Set(); // endpoints that have already given up this session
  let bannerShownEver = false; // the whole extension only ever shows one banner, ever

  function matchTarget(method, url) {
    if (method !== "GET" || typeof url !== "string") return null;
    for (const t of TARGET_PATTERNS) if (t.re.test(url)) return t.name;
    return null;
  }

  function backoffDelay(attempt) {
    const raw = Math.min(BASE_DELAY_MS * 2 ** (attempt - 1), MAX_DELAY_MS);
    return raw * (0.75 + Math.random() * 0.5);
  }

  // ---------------------------------------------------------------------
  // Banner: created at most once, ever, then fully removed from the DOM.
  // ---------------------------------------------------------------------
  function showBannerOnceThenRemove(message) {
    if (bannerShownEver) return; // never show a second one, period
    bannerShownEver = true;

    const el = document.createElement("div");
    el.id = "kodub-status-banner";
    Object.assign(el.style, {
      position: "fixed",
      left: "50%",
      bottom: "24px",
      transform: "translateX(-50%)",
      maxWidth: "min(90vw, 420px)",
      padding: "10px 18px",
      borderRadius: "10px",
      background: "rgba(20, 20, 24, 0.88)",
      color: "#fff",
      fontFamily: "sans-serif",
      fontSize: "14px",
      lineHeight: "1.3",
      textAlign: "center",
      zIndex: "100000",
      pointerEvents: "none",
      boxShadow: "0 2px 10px rgba(0,0,0,0.35)",
      opacity: "0",
      transition: "opacity 0.25s ease",
    });
    el.textContent = message;
    (document.body || document.documentElement).appendChild(el);

    void el.offsetWidth; // reflow so the fade-in actually animates
    el.style.opacity = "1";

    setTimeout(() => {
      el.style.opacity = "0";
      setTimeout(() => {
        el.remove(); // fully gone from the DOM, not just hidden
      }, 300);
    }, BANNER_VISIBLE_MS);
  }

  // ---------------------------------------------------------------------
  // XHR patching
  // ---------------------------------------------------------------------
  const proto = XMLHttpRequest.prototype;
  const NativeOpen = proto.open;
  const NativeSend = proto.send;
  const nativeOnReadyStateChangeDescriptor = Object.getOwnPropertyDescriptor(
    proto,
    "onreadystatechange"
  );

  proto.open = function (method, url, ...rest) {
    this.__kodubMethod = method;
    this.__kodubUrl = url;
    this.__kodubAttempt = 1;
    this.__kodubTarget = matchTarget(method, url);
    return NativeOpen.call(this, method, url, ...rest);
  };

  proto.send = function (body) {
    this.__kodubBody = body;
    return NativeSend.call(this, body);
  };

  function handleReadyStateChange(xhr) {
    const userHandler = xhr.__kodubUserHandler;

    if (xhr.readyState !== XMLHttpRequest.DONE) {
      if (typeof userHandler === "function") userHandler.call(xhr);
      return;
    }

    const target = xhr.__kodubTarget;
    if (!target || silenced.has(target)) {
      // Not ours, or already given up on this endpoint this session:
      // deliver the result once, no retry, no banner, no DOM element.
      if (typeof userHandler === "function") userHandler.call(xhr);
      return;
    }

    const status = xhr.status;
    const attempt = xhr.__kodubAttempt || 1;
    const retryable = status === 0 || RETRYABLE_STATUSES.has(status);

    log(`${target}: attempt ${attempt} -> status ${status}`);

    if (retryable && attempt <= MAX_RETRIES) {
      // Retry quietly in the background -- no banner per attempt.
      const delay = backoffDelay(attempt);
      xhr.__kodubAttempt = attempt + 1;
      setTimeout(() => {
        NativeOpen.call(xhr, xhr.__kodubMethod, xhr.__kodubUrl, true);
        NativeSend.call(xhr, xhr.__kodubBody);
      }, delay);
      return;
    }

    if (retryable && attempt > 1) {
      silenced.add(target);
      log(`${target}: giving up after ${attempt} attempts \u2014 silenced for the rest of this session`);
      showBannerOnceThenRemove("Can\u2019t reach the online server right now \u2014 playing offline.");
    }

    if (typeof userHandler === "function") userHandler.call(xhr);
  }

  Object.defineProperty(proto, "onreadystatechange", {
    configurable: true,
    enumerable: true,
    get() {
      return this.__kodubUserHandler || null;
    },
    set(fn) {
      this.__kodubUserHandler = fn;
      if (!this.__kodubDispatcherAttached) {
        this.__kodubDispatcherAttached = true;
        const self = this;
        nativeOnReadyStateChangeDescriptor.set.call(self, function () {
          handleReadyStateChange(self);
        });
      }
    },
  });

  // ---------------------------------------------------------------------
  // Diagnostic helper, unchanged.
  // ---------------------------------------------------------------------
  window.__kodubDebugConnectivity = async function (
    url = "https://vps.kodub.com/v6/leaderboard?version=0.6.2&trackId=1&skip=0&amount=1&onlyVerified=false"
  ) {
    console.log("[kodub_resilience] testing raw connectivity to:", url);
    try {
      const res = await fetch(url, { method: "GET", mode: "cors" });
      const text = await res.text().catch(() => "<unreadable body>");
      console.log("[kodub_resilience] HTTP status:", res.status, res.statusText);
      console.log("[kodub_resilience] response body (truncated):", text.slice(0, 300));
    } catch (err) {
      console.log("[kodub_resilience] -> fetch() THREW (no response received at all):", err.message);
      console.log("[kodub_resilience] Matches a CORS block or a request that never left the browser \u2014 not a 503, not fixable by retrying.");
    }
  };

  window.__kodubResetSilencing = function () {
    silenced.clear();
    bannerShownEver = false;
    console.log("[kodub_resilience] silencing cleared.");
  };

  log("loaded (single-banner mode).");
})();
