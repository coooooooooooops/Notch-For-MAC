import SwiftUI
import AppKit
import WebKit
import Network

// PolyTrack in the notch. The game files live in NOTCH.app/Contents/Resources/game and are served
// to a WKWebView by a tiny loopback-only web server (127.0.0.1), so workers, wasm and saved
// progress (localStorage / IndexedDB) all behave exactly like a normal website.

let gameTab = 12   // index of the game tab in RootView.icons

// MARK: local static file server (loopback only)
final class LocalServer {
    static let shared = LocalServer()
    private var listener: NWListener?
    private(set) var port: UInt16 = 0
    private let root: URL
    private let q = DispatchQueue(label: "notch.localserver")

    init() {
        root = (Bundle.main.resourceURL ?? URL(fileURLWithPath: ".")).appendingPathComponent("game", isDirectory: true)
    }

    var hasGame: Bool { FileManager.default.fileExists(atPath: root.appendingPathComponent("index.html").path) }

    /// Calls `done` on the main queue with the port, or nil if no port could be opened.
    /// The first port is fixed on purpose: the web origin stays the same between launches, so your saves persist.
    func start(_ done: @escaping (UInt16?) -> Void) {
        if port != 0 { done(port); return }
        tryPort(47615, remaining: 12, done)
    }

    private func tryPort(_ p: UInt16, remaining: Int, _ done: @escaping (UInt16?) -> Void) {
        guard remaining > 0, let np = NWEndpoint.Port(rawValue: p) else { DispatchQueue.main.async { done(nil) }; return }
        let params = NWParameters.tcp
        params.requiredInterfaceType = .loopback
        guard let l = try? NWListener(using: params, on: np) else { tryPort(p + 1, remaining: remaining - 1, done); return }
        var finished = false
        l.stateUpdateHandler = { [weak self, weak l] st in
            switch st {
            case .ready:
                guard !finished else { return }
                finished = true
                self?.listener = l; self?.port = p
                DispatchQueue.main.async { done(p) }
            case .failed:
                guard !finished else { return }
                finished = true
                l?.cancel()
                self?.tryPort(p + 1, remaining: remaining - 1, done)
            default: break
            }
        }
        l.newConnectionHandler = { [weak self] c in self?.handle(c) }
        l.start(queue: q)
    }

    private func handle(_ c: NWConnection) {
        c.start(queue: q)
        readRequest(c, Data())
    }

    private func readRequest(_ c: NWConnection, _ buf: Data) {
        c.receive(minimumIncompleteLength: 1, maximumLength: 16384) { [weak self] data, _, isDone, err in
            guard let self = self else { c.cancel(); return }
            var b = buf
            if let d = data { b.append(d) }
            if let r = b.range(of: Data("\r\n\r\n".utf8)) {
                self.respond(c, String(decoding: b[b.startIndex..<r.lowerBound], as: UTF8.self))
            } else if err != nil || isDone || b.count > 65536 {
                c.cancel()
            } else {
                self.readRequest(c, b)
            }
        }
    }

    private func respond(_ c: NWConnection, _ head: String) {
        let lines = head.components(separatedBy: "\r\n")
        let parts = (lines.first ?? "").split(separator: " ")
        guard parts.count >= 2, parts[0] == "GET" || parts[0] == "HEAD" else { send(c, 405, "Method Not Allowed", Data(), [:]); return }
        let isHead = parts[0] == "HEAD"
        var path = String(parts[1])
        if let i = path.firstIndex(where: { $0 == "?" || $0 == "#" }) { path = String(path[path.startIndex..<i]) }
        path = path.removingPercentEncoding ?? path
        if path.hasSuffix("/") { path += "index.html" }
        let comps = path.split(separator: "/").map(String.init)
        if comps.contains("..") { send(c, 403, "Forbidden", Data(), [:]); return }
        let file = comps.reduce(root) { $0.appendingPathComponent($1) }
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: file.path, isDirectory: &isDir), !isDir.boolValue,
              let data = try? Data(contentsOf: file, options: .mappedIfSafe) else {
            send(c, 404, "Not Found", Data("Not found".utf8), ["Content-Type": "text/plain"]); return
        }
        var headers = ["Content-Type": LocalServer.mime(file.pathExtension.lowercased()), "Accept-Ranges": "bytes"]
        // Range support (Safari's media player asks for byte ranges)
        if let rl = lines.first(where: { $0.lowercased().hasPrefix("range:") }), let eq = rl.range(of: "bytes=") {
            let spec = rl[eq.upperBound...].trimmingCharacters(in: .whitespaces)
            let se = spec.split(separator: "-", maxSplits: 1, omittingEmptySubsequences: false).map(String.init)
            if se.count == 2 {
                var a = 0, b = data.count - 1
                if se[0].isEmpty, let n = Int(se[1]) { a = max(0, data.count - n) }
                else if let s = Int(se[0]) { a = s; if let e = Int(se[1]) { b = min(e, data.count - 1) } }
                if a <= b, a < data.count {
                    headers["Content-Range"] = "bytes \(a)-\(b)/\(data.count)"
                    send(c, 206, "Partial Content", data.subdata(in: a..<(b + 1)), headers, head: isHead); return
                }
                headers["Content-Range"] = "bytes */\(data.count)"
                send(c, 416, "Range Not Satisfiable", Data(), headers); return
            }
        }
        send(c, 200, "OK", data, headers, head: isHead)
    }

    private func send(_ c: NWConnection, _ code: Int, _ text: String, _ body: Data, _ headers: [String: String], head: Bool = false) {
        var h = "HTTP/1.1 \(code) \(text)\r\nContent-Length: \(body.count)\r\nConnection: close\r\n"
        for (k, v) in headers { h += "\(k): \(v)\r\n" }
        h += "\r\n"
        var out = Data(h.utf8)
        if !head { out.append(body) }
        c.send(content: out, contentContext: .finalMessage, isComplete: true, completion: .contentProcessed { _ in c.cancel() })
    }

    static func mime(_ ext: String) -> String {
        switch ext {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "json", "map": return "application/json; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "wasm": return "application/wasm"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "svg": return "image/svg+xml"
        case "mp3": return "audio/mpeg"
        case "ogg": return "audio/ogg"
        case "wav": return "audio/wav"
        case "woff2": return "font/woff2"
        case "woff": return "font/woff"
        case "ttf": return "font/ttf"
        case "glb": return "model/gltf-binary"
        default: return "application/octet-stream"
        }
    }
}

// MARK: game web view
// The web view is attached to the notch window ONCE and never removed: closing the notch only hides it,
// so the page (and whatever you were doing in it) is still there when you reopen. Your saves live in
// the web view's persistent storage AND in a mirror file (~/Library/Application Support/NOTCH/polytrack-save.json)
// that is restored automatically if the game's storage is ever empty.
final class PolyModel: NSObject, ObservableObject, WKNavigationDelegate, WKScriptMessageHandler {
    static let shared = PolyModel()
    @Published var ready = false
    @Published var error: String? { didSet { refreshVisibility() } }
    let wv: WKWebView
    private var started = false
    private var slotActive = false
    private let saveQ = DispatchQueue(label: "notch.polysave")

    static var saveURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("NOTCH", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent("polytrack-save.json")
    }

    /// Mirror file contents as a JSON object literal ("{}" if missing or damaged).
    static func savedJSON() -> String {
        guard let d = try? Data(contentsOf: saveURL),
              (try? JSONSerialization.jsonObject(with: d)) is [String: Any],
              let t = String(data: d, encoding: .utf8) else { return "{}" }
        return t
    }

    override init() {
        let cfg = WKWebViewConfiguration()
        cfg.mediaTypesRequiringUserActionForPlayback = []       // let the game play sound without an extra click
        cfg.websiteDataStore = WKWebsiteDataStore.default()      // persistent: keeps your PolyTrack saves
        let js = """
        (function(){
          var A=window.AudioContext||window.webkitAudioContext;
          if(A){window.__ac=[];var P=new Proxy(A,{construct:function(t,a){var c=new t(...a);window.__ac.push(c);return c;}});window.AudioContext=P;window.webkitAudioContext=P;}
          document.addEventListener('contextmenu',function(e){e.preventDefault();});
          var st=document.createElement('style');st.textContent='html,body{overscroll-behavior:none !important;}';
          (document.head||document.documentElement).appendChild(st);
          var ls;try{ls=window.localStorage;}catch(e){return;}
          var saved=\(PolyModel.savedJSON());
          try{for(var k in saved){if(ls.getItem(k)===null){ls.setItem(k,saved[k]);}}}catch(e){}
          var timer=null;
          function dump(){
            var o={};
            try{for(var i=0;i<ls.length;i++){var k=ls.key(i);if(k&&k.indexOf('polytrack')===0){o[k]=ls.getItem(k);}}}catch(e){}
            try{window.webkit.messageHandlers.notchSave.postMessage(JSON.stringify(o));}catch(e){}
          }
          window.__notchDump=dump;
          function sched(){clearTimeout(timer);timer=setTimeout(dump,400);}
          var sp=Storage.prototype,si=sp.setItem,ri=sp.removeItem,ci=sp.clear;
          sp.setItem=function(){var r=si.apply(this,arguments);if(this===ls)sched();return r;};
          sp.removeItem=function(){var r=ri.apply(this,arguments);if(this===ls)sched();return r;};
          sp.clear=function(){var r=ci.apply(this,arguments);if(this===ls)sched();return r;};
          window.addEventListener('pagehide',dump);
        })();
        """
        cfg.userContentController.addUserScript(WKUserScript(source: js, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        wv = WKWebView(frame: NSRect(x: 0, y: 0, width: 780, height: 380), configuration: cfg)
        super.init()
        wv.configuration.userContentController.add(self, name: "notchSave")
        wv.navigationDelegate = self
        wv.allowsBackForwardNavigationGestures = false
        if wv.responds(to: NSSelectorFromString("setDrawsBackground:")) { wv.setValue(false, forKey: "drawsBackground") }   // transparent until the game paints
        wv.wantsLayer = true
        wv.layer?.cornerRadius = 12
        wv.layer?.masksToBounds = true
        wv.isHidden = true
        BModel.noBounce(wv)
    }

    // MARK: attach / show / hide (never removed from the window once attached)
    func place(_ slot: NSView) {
        guard let host = slot.window?.contentView else { return }
        if wv.superview !== host {
            wv.removeFromSuperview()
            host.addSubview(wv, positioned: .above, relativeTo: nil)
        }
        let r = host.convert(slot.convert(slot.bounds, to: nil), from: nil)
        if r.width > 200, r.height > 120, r != wv.frame { wv.frame = r }   // ignore the tiny in-between sizes while the notch animates open
        slotActive = true
        refreshVisibility()
    }
    func unplace() { slotActive = false; refreshVisibility() }
    func refreshVisibility() { wv.isHidden = !(slotActive && error == nil) }

    /// Loads the game the first time the tab is opened.
    func start() {
        guard !started else { return }
        guard LocalServer.shared.hasGame else {
            error = "The game files are missing from the app.\nRebuild with the 'game' folder next to build.sh."
            return
        }
        started = true
        LocalServer.shared.start { [weak self] port in
            guard let self = self else { return }
            guard let port = port, let u = URL(string: "http://127.0.0.1:\(port)/index.html") else {
                self.error = "Couldn't start the local game server."
                self.started = false
                return
            }
            self.wv.load(URLRequest(url: u))
        }
    }

    func focus() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in
            guard let self = self, let p = (NSApp.delegate as? AppDelegate)?.panel else { return }
            p.makeKey()
            p.makeFirstResponder(self.wv)
        }
    }

    /// Notch closed / tab left: silence audio, flush the save mirror, tell the page it lost focus. The page itself stays loaded.
    func suspend() {
        guard started else { return }
        wv.evaluateJavaScript("""
        try{
          if(window.__notchDump)window.__notchDump();
          (window.__ac||[]).forEach(function(c){c.suspend();});
          window.__pl=[].slice.call(document.querySelectorAll('audio,video')).filter(function(m){return !m.paused;});
          window.__pl.forEach(function(m){m.pause();});
          window.dispatchEvent(new Event('blur'));
        }catch(e){}
        """, completionHandler: nil)
    }

    func resume() {
        guard started else { return }
        wv.evaluateJavaScript("""
        try{
          (window.__ac||[]).forEach(function(c){c.resume();});
          (window.__pl||[]).forEach(function(m){m.play();});
          window.__pl=[];
          window.dispatchEvent(new Event('focus'));
        }catch(e){}
        """, completionHandler: nil)
    }

    // MARK: save mirror
    func userContentController(_ c: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "notchSave", let text = message.body as? String,
              let data = text.data(using: .utf8),
              (try? JSONSerialization.jsonObject(with: data)) is [String: Any] else { return }
        saveQ.async { try? data.write(to: PolyModel.saveURL, options: .atomic) }
    }

    // MARK: navigation
    func webView(_ w: WKWebView, didFinish n: WKNavigation!) { ready = true; BModel.noBounce(w) }
    func webView(_ w: WKWebView, didFail n: WKNavigation!, withError e: Error) { error = e.localizedDescription }
    func webView(_ w: WKWebView, didFailProvisionalNavigation n: WKNavigation!, withError e: Error) { error = e.localizedDescription }
    /// If macOS ever reclaims the web process while the notch is closed, bring the game straight back.
    func webViewWebContentProcessDidTerminate(_ w: WKWebView) { ready = false; w.reload() }
}

/// Invisible placeholder in the tab layout: tells the (permanently attached) game web view where to sit.
final class PolySlotView: NSView {
    override func layout() { super.layout(); PolyModel.shared.place(self) }
    override func viewDidMoveToWindow() { super.viewDidMoveToWindow(); if window != nil { PolyModel.shared.place(self) } }
}
struct PolySlot: NSViewRepresentable {
    func makeNSView(context: Context) -> PolySlotView { PolySlotView() }
    func updateNSView(_ v: PolySlotView, context: Context) { PolyModel.shared.place(v) }
    static func dismantleNSView(_ v: PolySlotView, coordinator: ()) { PolyModel.shared.unplace() }
}

struct PolyView: View {
    @ObservedObject var m = PolyModel.shared

    var body: some View {
        ZStack {
            Color.black
            if let e = m.error {
                Text(e).font(.caption).foregroundColor(.orange).multilineTextAlignment(.center).padding()
            } else if !m.ready {
                VStack(spacing: 8) {
                    ProgressView().controlSize(.small)
                    Text("Loading PolyTrack...").font(.caption).foregroundColor(.gray)
                }
            }
            PolySlot()
        }
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .onAppear { m.start(); m.resume(); m.focus() }
        .onDisappear { m.suspend() }
    }
}
